package vn.viettuts.qlsv.view;

import vn.viettuts.qlsv.entity.Student;
import javax.swing.JOptionPane;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

    /**
     *
     * @author ADMIN
     */
public class StudentInforView extends javax.swing.JDialog {
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    /**
    * Creates new form StudentInforView
    */
    public StudentInforView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
    }

    public Student getStudentInfor(){
        // validate student
        if (!validateName() || !validateAge() || !validateAddress() || !validateGPA() 
                || !validateGrade() || !validateDateDoan() || ! validatePlaceDoan() || !validatePlaceDang()) {
            return null;
        }
        try {
            Student student = new Student();

            if (idField.getText() != null && !"".equals(idField.getText())) {
                student.setId(Integer.parseInt(idField.getText()));
            }
            student.setName(nameField.getText().trim());
            student.setAge(Byte.parseByte(ageField.getText().trim()));
            student.setAddress(addressArea.getText().trim());
            student.setGpa(Float.parseFloat(gpaField.getText().trim()));
            student.setGrade(gradeField.getText().trim());

            Date dateDoan = DoanDateChooser.getDate();
            if (dateDoan != null) {
                String dateString = sdf.format(dateDoan);
                student.setDateJoinDoan(dateString);  // Lưu dưới dạng String
            }

            student.setPlaceJoinDoan(placeDoanField.getText().trim());
            student.setIsDoanPhi(isDoanPhi.isSelected());

            Date dateDang = DangDateChooser.getDate();
            if (dateDang != null) {
                String dateString = sdf.format(dateDang);
                student.setDateJoinDang(dateString);  // Lưu dưới dạng String
            }

            student.setPlaceJoinDang(placeDangField.getText().trim());
            student.setIsDangPhi(isDangPhi.isSelected());
            student.setActivity(activityArea.getText());
            student.setReward(rewardArea.getText());
            student.setPunishment(punishmentArea.getText());

            return student;
        } catch (NumberFormatException e) {
            showMessage(e.getMessage());
        }
        return null;      
    }

    public boolean validateName(){
        String name = nameField.getText();
        if (name == null || "".equals(name.trim())) {
            nameField.requestFocus();
            showMessage("Name không được trống.");
            return false;
        }
        return true;
    }

    private boolean validateAddress() {
        String address = addressArea.getText();
        if (address == null || "".equals(address.trim())) {
            addressArea.requestFocus();
            showMessage("Address không được trống.");
            return false;
        }
        return true;
    }

    private boolean validateGrade() {
        String address = gradeField.getText();
        if (address == null || "".equals(address.trim())) {
            gradeField.requestFocus();
            showMessage("Grade không được trống.");
            return false;
        }
        return true;
    }

    private boolean validateAge() {
        try {
            Byte age = Byte.valueOf(ageField.getText().trim());
            if (age < 0 || age > 100) {
                ageField.requestFocus();
                showMessage("Age không hợp lệ, age nên trong khoảng 0 đến 100.");
                return false;
            }
        } catch (NumberFormatException e) {
            ageField.requestFocus();
            showMessage("Age không hợp lệ!");
            return false;
        }
        return true;
    }

    private boolean validateGPA() {
        try {
            Float gpa = Float.valueOf(gpaField.getText().trim());
            if (gpa < 0 || gpa > 10) {
                gpaField.requestFocus();
                showMessage("GPA không hợp lệ, gpa nên trong khoảng 0 đến 10.");
                return false;
            }
        } catch (NumberFormatException e) {
            gpaField.requestFocus();
            showMessage("GPA không hợp lệ!");
            return false;
        }
        return true;
    }


    private boolean validateDateDoan() {
        Date date = DoanDateChooser.getDate();  // Lấy giá trị Date từ JDateChooser
        if (date == null) {  // Kiểm tra nếu ngày chưa được chọn
            DoanDateChooser.requestFocus();
            showMessage("Ngày vào Đoàn không được trống.");
            return false;
        }
        return true;
    }

    private boolean validatePlaceDoan() {
        String place = placeDoanField.getText();
        if (place == null || "".equals(place.trim())) {
            placeDoanField.requestFocus();
            showMessage("Nơi vào Đoàn không được trống.");
            return false;
        }
        return true;
    }
    
    private boolean validatePlaceDang() {
        Date date = DangDateChooser.getDate();
        String place = placeDangField.getText();

        // Chỉ kiểm tra "Nơi vào Đảng" khi có ngày vào Đảng
        if (date != null) {
            if (place == null || place.trim().isEmpty()) {
                placeDangField.requestFocus();
                showMessage("Nơi vào Đảng không được trống.");
                return false;
            }
        }

        return true;
    }


    public String getIDField(){
        return idField.getText();
    }

    public void setIDField(String s){
        this.idField.setText(s);
    }

    public void setNameField(String s){
        this.nameField.setText(s);
    }

    public void setAgeField(String s){
        this.ageField.setText(s);
    }

    public void setGradeField(String s){
        this.gradeField.setText(s);
    }

    public void setAddressArea(String s){
        this.addressArea.setText(s);
    }

    public void setGPAField(String s){
        this.gpaField.setText(s);
    }

    public void setDateDoanField(String s) {
        try {
            // Định dạng chuỗi ngày tháng trước khi chuyển sang Date
            Date date = sdf.parse(s);  // Chuyển đổi chuỗi s thành Date
            this.DoanDateChooser.setDate(date);  // Đặt Date vào JDateChooser
        } catch (ParseException e) {
        }
    }

    public void setPlaceDoanField(String s){
        this.placeDoanField.setText(s);
    }

    public void setDateDangField(String s) {
        try {
            // Định dạng chuỗi ngày tháng trước khi chuyển sang Date
            Date date = sdf.parse(s);  // Chuyển đổi chuỗi s thành Date
            this.DangDateChooser.setDate(date);  // Đặt Date vào JDateChooser
        } catch (ParseException e) {
        }
    }

    public void setPlaceDangField(String s){
        this.placeDangField.setText(s);
    }

    public void setActivityArea(String s){
        this.activityArea.setText(s);
    }

    public void setRewardArea(String s){
        this.rewardArea.setText(s);
    }

    public void setPunishmentArea(String s){
        this.punishmentArea.setText(s);
    }

    public void setDangPhiCheck(boolean isDangPhi){
        this.isDangPhi.setSelected(isDangPhi);
    }

    public void setDoanPhiCheck(boolean isDoanPhi){
        this.isDoanPhi.setSelected(isDoanPhi);
    }

    public void enableSaveBtn(boolean isEnable){
        this.saveBtn.setEnabled(isEnable);
        this.saveBtn.setVisible(isEnable);
    }

    public void enableEditBtn(boolean isEnable){
        this.editButton.setEnabled(isEnable);
        this.editButton.setVisible(isEnable);
    }

    public void enableDeleteBtn(boolean isEnable){
        this.deleteButton.setEnabled(isEnable);
        this.deleteButton.setVisible(isEnable);
    }

    public void showMessage(String message){
        JOptionPane.showMessageDialog(this, message);
    }

    public boolean getSaveBtnAction(){
        return saveAction;
    }

    public void setSaveBtnAction(boolean isEnable){
        this.saveAction = isEnable;
    }

    public boolean getDeleteBtnAction(){
        return deleteAction;
    }

    public void setDeleteBtnAction(boolean isEnable){
        this.deleteAction = isEnable;
    }

    public boolean getEditBtnAction(){
        return editAction;
    }

    public void setEditBtnAction(boolean isEnable){
        this.editAction = isEnable;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelTittle = new javax.swing.JLabel();
        IDjLabel = new javax.swing.JLabel();
        idField = new javax.swing.JTextField();
        NamejLabel = new javax.swing.JLabel();
        jLabelGrade = new javax.swing.JLabel();
        jLabelAddress = new javax.swing.JLabel();
        jLabelNgayvaodoan = new javax.swing.JLabel();
        jLabelNgayvaodang = new javax.swing.JLabel();
        jLabelDoanphi = new javax.swing.JLabel();
        jLabelAge = new javax.swing.JLabel();
        ageField = new javax.swing.JTextField();
        nameField = new javax.swing.JTextField();
        gradeField = new javax.swing.JTextField();
        jLabelGPA = new javax.swing.JLabel();
        gpaField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        addressArea = new javax.swing.JTextArea();
        jLabelNoivandoan = new javax.swing.JLabel();
        placeDoanField = new javax.swing.JTextField();
        jLabelNoivaodang = new javax.swing.JLabel();
        placeDangField = new javax.swing.JTextField();
        isDoanPhi = new javax.swing.JCheckBox();
        jLabelDangphi = new javax.swing.JLabel();
        jLabelKhenthuong = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        rewardArea = new javax.swing.JTextArea();
        jLabelKyluat = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        punishmentArea = new javax.swing.JTextArea();
        editButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        isDangPhi = new javax.swing.JCheckBox();
        jLabelPhongtrao = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        activityArea = new javax.swing.JTextArea();
        saveBtn = new javax.swing.JButton();
        DoanDateChooser = new com.toedter.calendar.JDateChooser();
        DangDateChooser = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Student Information");

        jLabelTittle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelTittle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTittle.setText("Student Information");

        IDjLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        IDjLabel.setText("ID");

        idField.setEditable(false);
        idField.setName("idField"); // NOI18N

        NamejLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        NamejLabel.setText("Name");

        jLabelGrade.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelGrade.setText("Grade");

        jLabelAddress.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelAddress.setText("Address");

        jLabelNgayvaodoan.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelNgayvaodoan.setText("Ngày vào Đoàn");

        jLabelNgayvaodang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelNgayvaodang.setText("Ngày vào Đảng");

        jLabelDoanphi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDoanphi.setText("Đóng Đoàn phí");

        jLabelAge.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelAge.setText("Age");

        jLabelGPA.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelGPA.setText("GPA");

        addressArea.setColumns(15);
        addressArea.setRows(3);
        jScrollPane1.setViewportView(addressArea);

        jLabelNoivandoan.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelNoivandoan.setText("Nơi vào Đoàn");

        jLabelNoivaodang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelNoivaodang.setText("Nơi vào Đảng");

        isDoanPhi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jLabelDangphi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDangphi.setText("Đóng Đảng phí");

        jLabelKhenthuong.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelKhenthuong.setText("Khen thưởng");

        rewardArea.setColumns(15);
        rewardArea.setRows(3);
        jScrollPane2.setViewportView(rewardArea);

        jLabelKyluat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelKyluat.setText("Kỷ luật");

        punishmentArea.setColumns(15);
        punishmentArea.setRows(3);
        jScrollPane3.setViewportView(punishmentArea);

        editButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        editButton.setText("Edit");
        editButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });

        deleteButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteButton.setText("Delete");
        deleteButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        isDangPhi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jLabelPhongtrao.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelPhongtrao.setText("Các phong trào ");

        activityArea.setColumns(15);
        activityArea.setRows(3);
        jScrollPane4.setViewportView(activityArea);

        saveBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        saveBtn.setText("Save New Student");
        saveBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        saveBtn.setEnabled(false);
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        DoanDateChooser.setDateFormatString("dd/MM/yyyy");

        DangDateChooser.setDateFormatString("dd/MM/yyyy");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelNgayvaodang)
                                .addGap(18, 18, 18)
                                .addComponent(DangDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelNgayvaodoan)
                            .addComponent(jLabelGrade))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelTittle)
                                .addGap(273, 273, 273)
                                .addComponent(isDangPhi))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelAddress)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelNoivaodang)
                                .addGap(18, 18, 18)
                                .addComponent(placeDangField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelDangphi)
                                .addGap(37, 37, 37))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelNoivandoan)
                                    .addComponent(jLabelAge)
                                    .addComponent(jLabelGPA))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(gpaField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(placeDoanField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelDoanphi)
                                        .addGap(18, 18, 18)
                                        .addComponent(isDoanPhi))
                                    .addComponent(ageField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelKhenthuong)
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(152, 152, 152)
                                .addComponent(editButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)
                                .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(saveBtn)
                                .addGap(24, 24, 24))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(jLabelKyluat)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane3))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NamejLabel)
                                    .addComponent(IDjLabel))
                                .addGap(72, 72, 72)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelPhongtrao)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(gradeField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DoanDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(17, 17, 17))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabelTittle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(IDjLabel)
                    .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NamejLabel)
                            .addComponent(jLabelAge)
                            .addComponent(ageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelAddress))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelGrade)
                            .addComponent(gradeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelGPA)
                            .addComponent(gpaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(isDoanPhi, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelNgayvaodoan)
                            .addComponent(jLabelNoivandoan)
                            .addComponent(placeDoanField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelDoanphi)))
                    .addComponent(DoanDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(isDangPhi)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelNgayvaodang)
                        .addComponent(jLabelNoivaodang)
                        .addComponent(placeDangField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabelDangphi))
                    .addComponent(DangDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelPhongtrao)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelKhenthuong)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                            .addComponent(jLabelKyluat)
                            .addComponent(jScrollPane2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(editButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // TODO add your handling code here:
        saveAction = true;
        if (getStudentInfor() != null){
            dispose();
        }
    }//GEN-LAST:event_saveBtnActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        deleteAction = true;
        dispose();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        // TODO add your handling code here:
        editAction = true;
        if (getStudentInfor() != null){
            dispose();
        }
    }//GEN-LAST:event_editButtonActionPerformed

    private boolean saveAction = false;
    private boolean deleteAction = false;
    private boolean editAction = false;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser DangDateChooser;
    private com.toedter.calendar.JDateChooser DoanDateChooser;
    private javax.swing.JLabel IDjLabel;
    private javax.swing.JLabel NamejLabel;
    private javax.swing.JTextArea activityArea;
    private javax.swing.JTextArea addressArea;
    private javax.swing.JTextField ageField;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton editButton;
    private javax.swing.JTextField gpaField;
    private javax.swing.JTextField gradeField;
    private javax.swing.JTextField idField;
    private javax.swing.JCheckBox isDangPhi;
    private javax.swing.JCheckBox isDoanPhi;
    private javax.swing.JLabel jLabelAddress;
    private javax.swing.JLabel jLabelAge;
    private javax.swing.JLabel jLabelDangphi;
    private javax.swing.JLabel jLabelDoanphi;
    private javax.swing.JLabel jLabelGPA;
    private javax.swing.JLabel jLabelGrade;
    private javax.swing.JLabel jLabelKhenthuong;
    private javax.swing.JLabel jLabelKyluat;
    private javax.swing.JLabel jLabelNgayvaodang;
    private javax.swing.JLabel jLabelNgayvaodoan;
    private javax.swing.JLabel jLabelNoivandoan;
    private javax.swing.JLabel jLabelNoivaodang;
    private javax.swing.JLabel jLabelPhongtrao;
    private javax.swing.JLabel jLabelTittle;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField nameField;
    private javax.swing.JTextField placeDangField;
    private javax.swing.JTextField placeDoanField;
    private javax.swing.JTextArea punishmentArea;
    private javax.swing.JTextArea rewardArea;
    private javax.swing.JButton saveBtn;
    // End of variables declaration//GEN-END:variables
}
