
package vn.viettuts.qlsv.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import vn.viettuts.qlsv.controller.LoginController;
import vn.viettuts.qlsv.dao.StudentDao;
import vn.viettuts.qlsv.entity.DangVien;
import vn.viettuts.qlsv.entity.DoanVien;
import vn.viettuts.qlsv.entity.Student;

/**
 *
 * @author miin
 */
public class StudentView extends javax.swing.JFrame implements ActionListener, ListSelectionListener{
    private HomeView homeView;
    private LoginView loginView;
    private DoanVienView doanvienView;
    private DangVienView dangvienView;
    private ThongkeView thongkeView;
    private FilterView filterView;
    private StudentDao studentDao;
    
    DefaultTableModel model;
    private boolean ASCSelected;
    private boolean DESCSelected;
    // định nghĩa các cột của bảng student
    private String [] ColumnNames = new String [] {
            "ID", "Họ và tên", "Tuổi", "Lớp", "Địa chỉ", "GPA", "Ngày vào Đoàn", "Nơi vào Đoàn", "Ngày vào Đảng", "Nơi vào Đảng", "Đoàn phí", "Đảng phí", "Phong trào", "Khen thưởng", "Kỷ luật"}; 
    
    // định nghĩa dữ liệu mặc định của bẳng student là rỗng
    private Object data = new Object [][] {};

    /**
     * Creates new form StudentViewReplace
     */
    public StudentView() {
        initComponents();
        customizeComponents(); // Dung phuong thuc tu dinh nghia
        loadImage();

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(255, 255, 255));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }
    private void customizeComponents() {    
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        ASC.setSelected(true);
        deleteStudentBtn.setEnabled(false);
        studentInforBtn.setEnabled(false);
        addStudentBtn.setEnabled(true);
        model = (DefaultTableModel) studentTable.getModel();
        
        // cài đặt các cột và data cho bảng student
        studentTable.setModel(new DefaultTableModel((Object[][]) data, ColumnNames));
    }
    
    private void loadImage() {
        try {
            // Sử dụng getResourceAsStream để tải ảnh từ resources
            InputStream logoStream = getClass().getResourceAsStream("/images/logo.jpg");
            
            BufferedImage originalImage1 = ImageIO.read(logoStream);
            
            // Đóng các stream sau khi sử dụng
            if (logoStream != null) logoStream.close();


            // Kích thước mong muốn cho JLabel
            int labelWidth1 = logoLabel.getWidth();
            int labelHeight1 = logoLabel.getHeight();

            // Điều chỉnh kích thước ảnh
            Image scaledImage1 = originalImage1.getScaledInstance(labelWidth1, labelHeight1, Image.SCALE_SMOOTH);

            // Đặt ảnh đã chỉnh kích thước vào JLabel
            logoLabel.setIcon(new ImageIcon(scaledImage1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
    
    public List<DoanVien> convertToDoanVienList(List<Student> studentList) {
        List<DoanVien> doanVienList = new ArrayList<>();
        for (Student student : studentList) {
            DoanVien doanVien = new DoanVien();
            doanVien.setId(student.getId());
            doanVien.setAge(student.getAge());
            doanVien.setName(student.getName());
            doanVien.setGrade(student.getGrade());
            doanVien.setAddress(student.getAddress());
            doanVien.setStatus(student.getAge() >= 30 ? "Hết tuổi đoàn" : "Đoàn viên");
            doanVien.setPlaceJoinDoan(student.getPlaceJoinDoan());
            doanVien.setDateJoinDoan(student.getDateJoinDoan());
            doanVien.setDoanPhi(student.isDoanPhi()? "Đã đóng" : "Chưa đóng");
            doanVien.setActivity(student.getActivity() == null ? "Chưa tham gia" : student.getActivity());
            doanVien.setReward(student.getReward() == null ? "Chưa tham gia" : student.getReward());
            doanVien.setPunishment(student.getPunishment() == null ? "Chưa tham gia" : student.getPunishment());

            doanVienList.add(doanVien);
        }
        return doanVienList;
    }

    public List<DangVien> convertToDangVienList(List<Student> studentList) {
        List<DangVien> dangVienList = new ArrayList<>();
        for (Student student : studentList) {
            DangVien dangVien = new DangVien();
            dangVien.setId(student.getId());
            dangVien.setAge(student.getAge());
            dangVien.setName(student.getName());
            dangVien.setGrade(student.getGrade());
            dangVien.setAddress(student.getAddress());
            dangVien.setLocation(student.getAddress());
            dangVien.setStatus(student.getDateJoinDang() == null ? "Chưa là đảng viên" : "Đảng viên");
            dangVien.setPlaceJoinDang(student.getPlaceJoinDang());
            dangVien.setDateJoinDang(student.getDateJoinDang());
            dangVien.setDangPhi(student.isDangPhi()? "Đã đóng" : "Chưa đóng");
            dangVien.setActivity(student.getActivity() == null ? "Chưa tham gia" : student.getActivity());
            dangVien.setReward(student.getReward() == null ? "Chưa tham gia" : student.getReward());
            dangVien.setPunishment(student.getPunishment() == null ? "Chưa tham gia" : student.getPunishment());

            dangVienList.add(dangVien);
        }
        return dangVienList;
    }
    
    public void showListStudents(List<Student> list) {
        int size = list.size();
        // với bảng studentTable có 15 cột, 
        // khởi tạo mảng 2 chiều students, trong đó:
        // số hàng: là kích thước của list student 
        // số cột: là 15
        Object [][] students = new Object[size][15];
        for (int i = 0; i < size; i++) {
            students[i][0] = list.get(i).getId();
            students[i][1] = list.get(i).getName();
            students[i][2] = list.get(i).getAge();
            students[i][3] = list.get(i).getGrade();
            students[i][4] = list.get(i).getAddress();
            students[i][5] = list.get(i).getGpa();
            students[i][6] = list.get(i).getDateJoinDoan();
            students[i][7] = list.get(i).getPlaceJoinDoan();

            if (list.get(i).getDateJoinDang() == null || list.get(i).getDateJoinDang().equals("")){
                students[i][8] = "Chưa vào Đảng";
            }else students[i][8] = list.get(i).getDateJoinDang();

            if (list.get(i).getDateJoinDang() == null || list.get(i).getDateJoinDang().equals("")){
                students[i][9] = "Chưa vào Đảng";
            }else students[i][9] = list.get(i).getPlaceJoinDang();
            
            if (list.get(i).getActivity() == null || list.get(i).getActivity().equals("")){
                students[i][12] = "Chưa tham gia";
            }else students[i][12] = list.get(i).getActivity();

            if (list.get(i).getReward() == null || list.get(i).getReward().equals("")){
                students[i][13] = "Không có";
            }else students[i][13] = list.get(i).getReward();

            if (list.get(i).getPunishment() == null || list.get(i).getPunishment().equals("")){
                students[i][14] = "Không có";
            }else students[i][14] = list.get(i).getPunishment();
            
            if (list.get(i).isDoanPhi()) students[i][10] = "Đã đóng";
            else students[i][10] = "Chưa đóng";
            if (list.get(i).isDangPhi()) students[i][11] = "Đã đóng";
            else students[i][11] = "Chưa đóng";
        }
        // Edit table
        studentTable.setModel(new DefaultTableModel(students, ColumnNames));
        TableColumnModel colStudentModel = studentTable.getColumnModel();
        colStudentModel.getColumn(0).setPreferredWidth(32);   
        colStudentModel.getColumn(1).setPreferredWidth(125);   
        colStudentModel.getColumn(2).setPreferredWidth(38);
        colStudentModel.getColumn(3).setPreferredWidth(45);
        colStudentModel.getColumn(4).setPreferredWidth(55);
        colStudentModel.getColumn(5).setPreferredWidth(40);
        colStudentModel.getColumn(6).setPreferredWidth(108);   
        colStudentModel.getColumn(7).setPreferredWidth(100);    
        colStudentModel.getColumn(8).setPreferredWidth(108);
        colStudentModel.getColumn(9).setPreferredWidth(100);   
        colStudentModel.getColumn(10).setPreferredWidth(65);
        colStudentModel.getColumn(11).setPreferredWidth(65);
        colStudentModel.getColumn(12).setPreferredWidth(120);   
        colStudentModel.getColumn(13).setPreferredWidth(90);
        colStudentModel.getColumn(14).setPreferredWidth(70);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logoutPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        addStudentBtn = new javax.swing.JButton();
        deleteStudentBtn = new javax.swing.JButton();
        showAllStudentBtn = new javax.swing.JButton();
        studentInforBtn = new javax.swing.JButton();
        filterBtn = new javax.swing.JButton();
        chucNangPanel = new javax.swing.JPanel();
        searchLabel = new javax.swing.JLabel();
        sortLabel = new javax.swing.JLabel();
        searchStudentNameBtn = new javax.swing.JButton();
        searchStudentGradeBtn = new javax.swing.JButton();
        searchStudentIDBtn = new javax.swing.JButton();
        isJoinedDangBtn = new javax.swing.JButton();
        isPaidDoanPhiBtn = new javax.swing.JButton();
        isPaidDangPhiBtn = new javax.swing.JButton();
        sortStudentIDBtn = new javax.swing.JButton();
        sortStudentNameBtn = new javax.swing.JButton();
        sortStudentGPABtn = new javax.swing.JButton();
        ASC = new javax.swing.JRadioButton();
        DESC = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        doanvienPanel = new javax.swing.JPanel();
        doanvienLabel = new javax.swing.JLabel();
        dangvienPanel = new javax.swing.JPanel();
        dangvienLabel = new javax.swing.JLabel();
        thongkePanel = new javax.swing.JPanel();
        thongkeLabel = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        logoutPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        sinhvienPanel = new javax.swing.JPanel();
        sinhvienLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        logoPanel = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản lý sinh viên\n");

        logoutPanel.setBackground(new java.awt.Color(255, 255, 255));
        logoutPanel.setToolTipText("Quản lý sinh viên");

        studentTable.setBackground(new java.awt.Color(255, 255, 204));
        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        studentTable.setToolTipText("");
        jScrollPane1.setViewportView(studentTable);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        addStudentBtn.setText("Add");
        addStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addStudentBtnActionPerformed(evt);
            }
        });

        deleteStudentBtn.setText("Delete");
        deleteStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        showAllStudentBtn.setText("Show All Students");
        showAllStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        studentInforBtn.setText("Student Infomation");
        studentInforBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        filterBtn.setText("Filter");
        filterBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(addStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(deleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(studentInforBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(showAllStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(filterBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentInforBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(showAllStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(filterBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        chucNangPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Chức năng"));
        chucNangPanel.setToolTipText("");

        searchLabel.setText("Search by");

        sortLabel.setText("Sort by");

        searchStudentNameBtn.setText("Name");
        searchStudentNameBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        searchStudentGradeBtn.setText("Grade");
        searchStudentGradeBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        searchStudentIDBtn.setText("ID");
        searchStudentIDBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        isJoinedDangBtn.setText("Đã vào Đảng");
        isJoinedDangBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        isPaidDoanPhiBtn.setText("Đã đóng Đoàn phí");
        isPaidDoanPhiBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        isPaidDangPhiBtn.setText("Đã đóng Đảng phí");
        isPaidDangPhiBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        sortStudentIDBtn.setText("ID");
        sortStudentIDBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        sortStudentNameBtn.setText("Name");
        sortStudentNameBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        sortStudentGPABtn.setText("GPA");
        sortStudentGPABtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortStudentGPABtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortStudentGPABtnActionPerformed(evt);
            }
        });

        ASC.setText("ASC");
        ASC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ASC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ASCActionPerformed(evt);
            }
        });

        DESC.setText("DESC");
        DESC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DESC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DESCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout chucNangPanelLayout = new javax.swing.GroupLayout(chucNangPanel);
        chucNangPanel.setLayout(chucNangPanelLayout);
        chucNangPanelLayout.setHorizontalGroup(
            chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sortLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(chucNangPanelLayout.createSequentialGroup()
                        .addComponent(searchStudentIDBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchStudentNameBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchStudentGradeBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isJoinedDangBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isPaidDoanPhiBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isPaidDangPhiBtn))
                    .addGroup(chucNangPanelLayout.createSequentialGroup()
                        .addComponent(sortStudentIDBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sortStudentNameBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sortStudentGPABtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ASC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DESC)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        chucNangPanelLayout.setVerticalGroup(
            chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLabel)
                    .addComponent(searchStudentIDBtn)
                    .addComponent(searchStudentNameBtn)
                    .addComponent(searchStudentGradeBtn)
                    .addComponent(isJoinedDangBtn)
                    .addComponent(isPaidDoanPhiBtn)
                    .addComponent(isPaidDangPhiBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sortLabel)
                    .addComponent(sortStudentIDBtn)
                    .addComponent(sortStudentNameBtn)
                    .addComponent(sortStudentGPABtn)
                    .addComponent(ASC)
                    .addComponent(DESC))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(chucNangPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(chucNangPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 204, 204));

        homePanel.setBackground(new java.awt.Color(0, 204, 204));
        homePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homePanelMouseClicked(evt);
            }
        });

        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        homeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        homeLabel.setText("Home");
        homeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        doanvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        doanvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doanvienPanelMouseClicked(evt);
            }
        });

        doanvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        doanvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        doanvienLabel.setText("Đoàn viên");
        doanvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout doanvienPanelLayout = new javax.swing.GroupLayout(doanvienPanel);
        doanvienPanel.setLayout(doanvienPanelLayout);
        doanvienPanelLayout.setHorizontalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        doanvienPanelLayout.setVerticalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dangvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        dangvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dangvienPanelMouseClicked(evt);
            }
        });

        dangvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dangvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dangvienLabel.setText("Đảng viên");
        dangvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout dangvienPanelLayout = new javax.swing.GroupLayout(dangvienPanel);
        dangvienPanel.setLayout(dangvienPanelLayout);
        dangvienPanelLayout.setHorizontalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        dangvienPanelLayout.setVerticalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongkePanel.setBackground(new java.awt.Color(0, 204, 204));
        thongkePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongkePanelMouseClicked(evt);
            }
        });

        thongkeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        thongkeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        thongkeLabel.setText("Thống kê");
        thongkeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout thongkePanelLayout = new javax.swing.GroupLayout(thongkePanel);
        thongkePanel.setLayout(thongkePanelLayout);
        thongkePanelLayout.setHorizontalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongkePanelLayout.setVerticalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashboardLabel.setText("DASHBOARD");

        logoutPanel1.setBackground(new java.awt.Color(0, 204, 204));
        logoutPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Đăng xuất\n");

        javax.swing.GroupLayout logoutPanel1Layout = new javax.swing.GroupLayout(logoutPanel1);
        logoutPanel1.setLayout(logoutPanel1Layout);
        logoutPanel1Layout.setHorizontalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoutPanel1Layout.setVerticalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        sinhvienPanel.setBackground(new java.awt.Color(0, 204, 204));

        sinhvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        sinhvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sinhvienLabel.setText("Sinh viên");
        sinhvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout sinhvienPanelLayout = new javax.swing.GroupLayout(sinhvienPanel);
        sinhvienPanel.setLayout(sinhvienPanelLayout);
        sinhvienPanelLayout.setHorizontalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        sinhvienPanelLayout.setVerticalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(doanvienPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dangvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongkePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logoutPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(sinhvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(homePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sinhvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(doanvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dangvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongkePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(logoutPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Hệ thống quản lý sinh viên");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout logoPanelLayout = new javax.swing.GroupLayout(logoPanel);
        logoPanel.setLayout(logoPanelLayout);
        logoPanelLayout.setHorizontalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoPanelLayout.setVerticalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout logoutPanelLayout = new javax.swing.GroupLayout(logoutPanel);
        logoutPanel.setLayout(logoutPanelLayout);
        logoutPanelLayout.setHorizontalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutPanelLayout.createSequentialGroup()
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1360, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        logoutPanelLayout.setVerticalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(logoutPanelLayout.createSequentialGroup()
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addStudentBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addStudentBtnActionPerformed

    private void ASCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ASCActionPerformed
        // TODO add your handling code here:
        if (ASC.isSelected()) {
            ASCSelected = true;
            DESCSelected = false;
            DESC.setSelected(false);
        } else {
            ASCSelected = false;
        }
    }//GEN-LAST:event_ASCActionPerformed

    private void sortStudentGPABtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortStudentGPABtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortStudentGPABtnActionPerformed

    private void DESCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DESCActionPerformed
        // TODO add your handling code here:
        if (DESC.isSelected()) {
            DESCSelected = true;
            ASCSelected = false;
            ASC.setSelected(false);
        } else {
            DESCSelected = false;
        }
    }//GEN-LAST:event_DESCActionPerformed

    private void homePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homePanelMouseClicked
        // TODO add your handling code here:
        homeView = new HomeView();
        
        homeView.setLocationRelativeTo(this);
        
        homeView.setVisible(true);
        this.setVisible(false);

        homePanel.setBackground(new Color(255, 255, 255));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_homePanelMouseClicked

    private void doanvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doanvienPanelMouseClicked
        // TODO add your handling code here:
        doanvienView = new DoanVienView();
        
        doanvienView.setLocationRelativeTo(loginView);
        doanvienView.showDoanVienView();
        this.setVisible(false);
        doanvienView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_doanvienPanelMouseClicked

    private void dangvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dangvienPanelMouseClicked
        // TODO add your handling code here:
        dangvienView = new DangVienView();

        dangvienView.showDangVienView();   
        dangvienView.setLocationRelativeTo(loginView);
        
        this.setVisible(false);
        dangvienView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_dangvienPanelMouseClicked

    private void thongkePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongkePanelMouseClicked
        // TODO add your handling code here:
        thongkeView = new ThongkeView();
        
        thongkeView.setLocationRelativeTo(loginView);
        
        this.setVisible(false);
        thongkeView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        thongkeView.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));

    }//GEN-LAST:event_thongkePanelMouseClicked

    private void logoutPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanel1MouseClicked
        // TODO add your handling code here:
        LoginView view = new LoginView();
        LoginController controller = new LoginController(view);
        // hiển thị màn hình login
        controller.showLoginView();
        
        this.setVisible(false);
        
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_logoutPanel1MouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ASC;
    private javax.swing.JRadioButton DESC;
    private javax.swing.JButton addStudentBtn;
    private javax.swing.JPanel chucNangPanel;
    private javax.swing.JLabel dangvienLabel;
    private javax.swing.JPanel dangvienPanel;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JButton deleteStudentBtn;
    private javax.swing.JLabel doanvienLabel;
    private javax.swing.JPanel doanvienPanel;
    private javax.swing.JButton filterBtn;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JButton isJoinedDangBtn;
    private javax.swing.JButton isPaidDangPhiBtn;
    private javax.swing.JButton isPaidDoanPhiBtn;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel logoutPanel;
    private javax.swing.JPanel logoutPanel1;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JButton searchStudentGradeBtn;
    private javax.swing.JButton searchStudentIDBtn;
    private javax.swing.JButton searchStudentNameBtn;
    private javax.swing.JButton showAllStudentBtn;
    private javax.swing.JLabel sinhvienLabel;
    private javax.swing.JPanel sinhvienPanel;
    private javax.swing.JLabel sortLabel;
    private javax.swing.JButton sortStudentGPABtn;
    private javax.swing.JButton sortStudentIDBtn;
    private javax.swing.JButton sortStudentNameBtn;
    private javax.swing.JButton studentInforBtn;
    private javax.swing.JTable studentTable;
    private javax.swing.JLabel thongkeLabel;
    private javax.swing.JPanel thongkePanel;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    /**
     * Lấy danh sách thông tin student từ Table
     * 
     * @return
     */
    public List<Integer> getListStudentIDTable(){
        List<Integer> listStudentID = new ArrayList<>();
        TableModel tableModel = studentTable.getModel();
        int rowCount = tableModel.getRowCount();
        
        for (int i=0; i< rowCount; i++){
            int id = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
            listStudentID.add(id);
        }
        return listStudentID;
    }
    
    public JTable getStudentTable(){
        return this.studentTable;
    }
    
    public int getStuTabSelectedRow(){
        return studentTable.getSelectedRow();
    }
    
    public void enableStuInforBtn(boolean isEnable){
        this.studentInforBtn.setEnabled(isEnable);
    }
    
    public void setEnableDeleteBtn(boolean isEnable){
        deleteStudentBtn.setEnabled(isEnable);
    }
    
    public boolean enableASCBtn(){
        return ASCSelected;
    }
    public boolean enableDESCBtn(){
        return DESCSelected;
    }
    
    public void addAddStudentListener(ActionListener listener) {
        addStudentBtn.addActionListener(listener);
    }
    
    public void addFilterStudentListener(ActionListener listener) {
        filterBtn.addActionListener(listener);
    }
    
    public void addDeleteStudentListener(ActionListener listener) {
        deleteStudentBtn.addActionListener(listener);
    }
    
    public void addSortStudentIDListener(ActionListener listener) {
        sortStudentIDBtn.addActionListener(listener);
    }
    
    public void addSortStudentGPAListener(ActionListener listener) {
        sortStudentGPABtn.addActionListener(listener);
    }
    
    public void addSortStudentNameListener(ActionListener listener) {
        sortStudentNameBtn.addActionListener(listener);
    }
    
    public void addStudentInformationListener(ActionListener listener){
        studentInforBtn.addActionListener(listener);
    }
    
    public void addShowAllStudentListener(ActionListener listener){
        showAllStudentBtn.addActionListener(listener);
    }
    
    public void addSearchStudentIDListener(ActionListener listener){
        searchStudentIDBtn.addActionListener(listener);
    }
    
    public void addSearchStudentNameListener(ActionListener listener){
        searchStudentNameBtn.addActionListener(listener);
    }
    
    public void addSearchStudentGradeListener(ActionListener listener){
        searchStudentGradeBtn.addActionListener(listener);
    }
    
    public void addSearchStudentJoinedDang(ActionListener listener){
        isJoinedDangBtn.addActionListener(listener);
    }
    
    public void addSearchStudentPaidDoanPhi(ActionListener listener){
        isPaidDoanPhiBtn.addActionListener(listener);
    }
    
    public void addSearchStudentPaidDangPhi(ActionListener listener){
        isPaidDangPhiBtn.addActionListener(listener);
    }
    
    public void addListStudentSelectionListener(ListSelectionListener listener) {
        studentTable.getSelectionModel().addListSelectionListener(listener);
    }
}
