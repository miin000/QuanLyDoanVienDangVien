
package vn.viettuts.qlsv.entity;

/**
 *
 * @author miin
 */
public class DangVien {
    private static final long serialVersionUID = 1L;
    private int id;
    private String name, grade, address, reward, punishment, activity;
    private String placeJoinDang;
    private String dateJoinDang;
    private String dangPhi;
    private byte age;
    private String location, status;

    public DangVien() {
    }

    public DangVien(int id, String name, String grade, String address, String reward, String punishment, String activity, String placeJoinDang, String dateJoinDang, String dangPhi, byte age, String location, String status) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.address = address;
        this.reward = reward;
        this.punishment = punishment;
        this.activity = activity;
        this.placeJoinDang = placeJoinDang;
        this.dateJoinDang = dateJoinDang;
        this.dangPhi = dangPhi;
        this.age = age;
        this.location = location;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getPunishment() {
        return punishment;
    }

    public void setPunishment(String punishment) {
        this.punishment = punishment;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getPlaceJoinDang() {
        return placeJoinDang;
    }

    public void setPlaceJoinDang(String placeJoinDang) {
        this.placeJoinDang = placeJoinDang;
    }

    public String getDateJoinDang() {
        return dateJoinDang;
    }

    public void setDateJoinDang(String dateJoinDang) {
        this.dateJoinDang = dateJoinDang;
    }

    public String getDangPhi() {
        return dangPhi;
    }

    public void setDangPhi(String dangPhi) {
        this.dangPhi = dangPhi;
    }

    public byte getAge() {
        return age;
    }

    public void setAge(byte age) {
        this.age = age;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
    
}
