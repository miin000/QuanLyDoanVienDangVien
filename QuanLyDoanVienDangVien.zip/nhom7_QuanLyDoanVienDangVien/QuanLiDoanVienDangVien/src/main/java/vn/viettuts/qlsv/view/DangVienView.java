
package vn.viettuts.qlsv.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import vn.viettuts.qlsv.controller.LoginController;
import vn.viettuts.qlsv.controller.StudentController;
import vn.viettuts.qlsv.dao.StudentDao;
import vn.viettuts.qlsv.entity.DangVien;
import vn.viettuts.qlsv.entity.Student;

/**
 *
 * @author miin
 */
public class DangVienView extends javax.swing.JFrame {
    private LoginView loginView = new LoginView();
    private StudentView studentView;
    private HomeView homeView;
    private DoanVienView doanvienView;
    private ThongkeView thongkeView;
    private FilterView filterView;
    private StudentDao studentDao;

    private List<DangVien> searchResultList = new ArrayList<>();
    
    DefaultTableModel model;
    private boolean ASCSelected;
    private boolean DESCSelected;
    
    private String [] ColumnNames = new String [] {
            "ID", "Họ và tên", "Tuổi", "Lớp", "Địa chỉ", "Trạng thái", "Ngày vào Đảng", "Nơi vào Đảng", "Đảng phí", "Địa chỉ công tác", "Phong trào", "Khen thưởng", "Kỷ luật"};
    
    // định nghĩa dữ liệu mặc định của bẳng là rỗng
    private Object data = new Object [][] {};
    /**
     * Creates new form DangVienView
     */
    public DangVienView() {
        initComponents();
        customizeComponents();
        loadImage();

        addStudentBtn.setEnabled(false);
        deleteStudentBtn.setEnabled(false);
        studentInforBtn.setEnabled(false);
        
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(255, 255, 255));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }
    
    private void customizeComponents() {    
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        ASC.setSelected(true);
        model = (DefaultTableModel) dangvienTable.getModel();
        
        // cài đặt các cột và data cho bảng student
        dangvienTable.setModel(new DefaultTableModel((Object[][]) data, ColumnNames));
    }
    
    private void loadImage() {
        try {
            // Sử dụng getResourceAsStream để tải ảnh từ resources
            InputStream logoStream = getClass().getResourceAsStream("/images/logo.jpg");
            
            BufferedImage originalImage1 = ImageIO.read(logoStream);
            
            // Đóng các stream sau khi sử dụng
            if (logoStream != null) logoStream.close();

            // Kích thước mong muốn cho JLabel
            int labelWidth1 = logoLabel.getWidth();
            int labelHeight1 = logoLabel.getHeight();

            // Điều chỉnh kích thước ảnh
            Image scaledImage1 = originalImage1.getScaledInstance(labelWidth1, labelHeight1, Image.SCALE_SMOOTH);

            // Đặt ảnh đã chỉnh kích thước vào JLabel
            logoLabel.setIcon(new ImageIcon(scaledImage1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getQuantityDangVien() {
        List<DangVien> list = getListDangVien();
        return String.valueOf(list.size());  // Trả về số lượng Đảng viên dưới dạng chuỗi
    }

    public void showDangVienView() {
        studentView = new StudentView();
        studentDao = new StudentDao();
        
        List<Student> studentList = studentDao.getListStudents();
        
        List<Student> filteredList = studentList.stream()
        .filter(student -> student.getDateJoinDang() != null && !student.getDateJoinDang().isEmpty())
        .collect(Collectors.toList());
        
        List<DangVien> dangVienList = studentView.convertToDangVienList(filteredList);
        this.showListDangVien(dangVienList);
    }
    
    public List<DangVien> getListDangVien() {
        studentView = new StudentView();
        studentDao = new StudentDao();
        List<Student> studentList = studentDao.getListStudents();
        
        List<Student> filteredList = studentList.stream()
        .filter(student -> student.getDateJoinDang() != null && !student.getDateJoinDang().isEmpty())
        .collect(Collectors.toList());
        
        List<DangVien> dangVienList = studentView.convertToDangVienList(filteredList);
        return dangVienList;
    }
    
    public void showListDangVien(List<DangVien> list) {
        int size = list.size();
        model.setRowCount(0); // Xóa dữ liệu cũ
        // với bảng studentTable có 15 cột, 
        // khởi tạo mảng 2 chiều listDangVien, trong đó:
        // số hàng: là kích thước của list student 
        // số cột: là 15
        Object [][] listDangVien = new Object[size][13];
        for (int i = 0; i < size; i++) {
            listDangVien[i][0] = list.get(i).getId();
            listDangVien[i][1] = list.get(i).getName();
            listDangVien[i][2] = list.get(i).getAge();
            listDangVien[i][3] = list.get(i).getGrade();
            listDangVien[i][4] = list.get(i).getAddress();
            listDangVien[i][6] = list.get(i).getDateJoinDang();
            listDangVien[i][7] = list.get(i).getPlaceJoinDang();
            listDangVien[i][8] = list.get(i).getDangPhi();       
            listDangVien[i][9] = list.get(i).getLocation();
            listDangVien[i][5] = list.get(i).getStatus();

            if (list.get(i).getActivity() == null || list.get(i).getActivity().equals("")){
                listDangVien[i][10] = "Chưa tham gia";
            }else listDangVien[i][10] = list.get(i).getActivity();

            if (list.get(i).getReward() == null || list.get(i).getReward().equals("")){
                listDangVien[i][11] = "Không có";
            }else listDangVien[i][11] = list.get(i).getReward();

            if (list.get(i).getPunishment() == null || list.get(i).getPunishment().equals("")){
                listDangVien[i][12] = "Không có";
            }else listDangVien[i][12] = list.get(i).getPunishment();
            
        }
        // Edit table
        dangvienTable.setModel(new DefaultTableModel(listDangVien, ColumnNames));
        TableColumnModel colStudentModel = dangvienTable.getColumnModel();
        colStudentModel.getColumn(0).setPreferredWidth(32);   
        colStudentModel.getColumn(1).setPreferredWidth(140);   
        colStudentModel.getColumn(2).setPreferredWidth(38);
        colStudentModel.getColumn(3).setPreferredWidth(45);
        colStudentModel.getColumn(4).setPreferredWidth(80);
        colStudentModel.getColumn(5).setPreferredWidth(80);
        colStudentModel.getColumn(6).setPreferredWidth(100);
        colStudentModel.getColumn(7).setPreferredWidth(140); 
        colStudentModel.getColumn(8).setPreferredWidth(100);    
        colStudentModel.getColumn(9).setPreferredWidth(108);   
        colStudentModel.getColumn(10).setPreferredWidth(150);   
        colStudentModel.getColumn(11).setPreferredWidth(150);
        colStudentModel.getColumn(12).setPreferredWidth(150);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dangvienTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        doanvienPanel = new javax.swing.JPanel();
        doanvienLabel = new javax.swing.JLabel();
        dangvienPanel = new javax.swing.JPanel();
        dangvienLabel = new javax.swing.JLabel();
        thongkePanel = new javax.swing.JPanel();
        thongkeLabel = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        logoutPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        sinhvienPanel = new javax.swing.JPanel();
        sinhvienLabel = new javax.swing.JLabel();
        logoPanel = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        chucNangPanel1 = new javax.swing.JPanel();
        searchLabel1 = new javax.swing.JLabel();
        sortLabel1 = new javax.swing.JLabel();
        searchStudentNameBtn = new javax.swing.JButton();
        searchStudentGradeBtn = new javax.swing.JButton();
        searchStudentIDBtn = new javax.swing.JButton();
        isPaidDangPhiBtn = new javax.swing.JButton();
        sortStudentIDBtn = new javax.swing.JButton();
        sortStudentNameBtn = new javax.swing.JButton();
        ASC = new javax.swing.JRadioButton();
        DESC = new javax.swing.JRadioButton();
        showAllStudentBtn = new javax.swing.JButton();
        addStudentBtn = new javax.swing.JButton();
        deleteStudentBtn = new javax.swing.JButton();
        studentInforBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản lý đảng viên");

        dangvienTable.setBackground(new java.awt.Color(255, 255, 204));
        dangvienTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(dangvienTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(0, 204, 204));

        homePanel.setBackground(new java.awt.Color(0, 204, 204));
        homePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homePanelMouseClicked(evt);
            }
        });

        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        homeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        homeLabel.setText("Home");
        homeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        doanvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        doanvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doanvienPanelMouseClicked(evt);
            }
        });

        doanvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        doanvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        doanvienLabel.setText("Đoàn viên");
        doanvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout doanvienPanelLayout = new javax.swing.GroupLayout(doanvienPanel);
        doanvienPanel.setLayout(doanvienPanelLayout);
        doanvienPanelLayout.setHorizontalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        doanvienPanelLayout.setVerticalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dangvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        dangvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dangvienPanelMouseClicked(evt);
            }
        });

        dangvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dangvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dangvienLabel.setText("Đảng viên");
        dangvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout dangvienPanelLayout = new javax.swing.GroupLayout(dangvienPanel);
        dangvienPanel.setLayout(dangvienPanelLayout);
        dangvienPanelLayout.setHorizontalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        dangvienPanelLayout.setVerticalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongkePanel.setBackground(new java.awt.Color(0, 204, 204));
        thongkePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongkePanelMouseClicked(evt);
            }
        });

        thongkeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        thongkeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        thongkeLabel.setText("Thống kê");
        thongkeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout thongkePanelLayout = new javax.swing.GroupLayout(thongkePanel);
        thongkePanel.setLayout(thongkePanelLayout);
        thongkePanelLayout.setHorizontalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongkePanelLayout.setVerticalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashboardLabel.setText("DASHBOARD");

        logoutPanel.setBackground(new java.awt.Color(0, 204, 204));
        logoutPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanelMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Đăng xuất\n");

        javax.swing.GroupLayout logoutPanelLayout = new javax.swing.GroupLayout(logoutPanel);
        logoutPanel.setLayout(logoutPanelLayout);
        logoutPanelLayout.setHorizontalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoutPanelLayout.setVerticalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        sinhvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        sinhvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sinhvienPanelMouseClicked(evt);
            }
        });

        sinhvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        sinhvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sinhvienLabel.setText("Sinh viên");
        sinhvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout sinhvienPanelLayout = new javax.swing.GroupLayout(sinhvienPanel);
        sinhvienPanel.setLayout(sinhvienPanelLayout);
        sinhvienPanelLayout.setHorizontalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        sinhvienPanelLayout.setVerticalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(doanvienPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dangvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongkePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logoutPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(sinhvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(homePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sinhvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(doanvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dangvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongkePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(logoutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout logoPanelLayout = new javax.swing.GroupLayout(logoPanel);
        logoPanel.setLayout(logoPanelLayout);
        logoPanelLayout.setHorizontalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
        );
        logoPanelLayout.setVerticalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Hệ thống quản lý đảng viên");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );

        chucNangPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Chức năng\n"));
        chucNangPanel1.setToolTipText("");

        searchLabel1.setText("Search by");

        sortLabel1.setText("Sort by");

        searchStudentNameBtn.setText("Name");
        searchStudentNameBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchStudentNameBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchStudentNameBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchStudentNameBtnMouseEntered(evt);
            }
        });

        searchStudentGradeBtn.setText("Grade");
        searchStudentGradeBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchStudentGradeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchStudentGradeBtnMouseClicked(evt);
            }
        });

        searchStudentIDBtn.setText("ID");
        searchStudentIDBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchStudentIDBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchStudentIDBtnMouseClicked(evt);
            }
        });

        isPaidDangPhiBtn.setText("Đã đóng Đảng phí");
        isPaidDangPhiBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        isPaidDangPhiBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                isPaidDangPhiBtnMouseClicked(evt);
            }
        });
        isPaidDangPhiBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isPaidDangPhiBtnActionPerformed(evt);
            }
        });

        sortStudentIDBtn.setText("ID");
        sortStudentIDBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortStudentIDBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sortStudentIDBtnMouseClicked(evt);
            }
        });

        sortStudentNameBtn.setText("Name");
        sortStudentNameBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortStudentNameBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sortStudentNameBtnMouseClicked(evt);
            }
        });

        ASC.setText("ASC");
        ASC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ASC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ASCActionPerformed(evt);
            }
        });

        DESC.setText("DESC");
        DESC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DESC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DESCActionPerformed(evt);
            }
        });

        showAllStudentBtn.setText("Hiển thị toàn bộ đảng viên");
        showAllStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        showAllStudentBtn.setMaximumSize(new java.awt.Dimension(171, 52));
        showAllStudentBtn.setPreferredSize(new java.awt.Dimension(171, 52));
        showAllStudentBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showAllStudentBtnMouseClicked(evt);
            }
        });

        addStudentBtn.setText("Add");
        addStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addStudentBtn.setMaximumSize(new java.awt.Dimension(72, 52));
        addStudentBtn.setPreferredSize(new java.awt.Dimension(72, 52));
        addStudentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addStudentBtnActionPerformed(evt);
            }
        });

        deleteStudentBtn.setText("Delete");
        deleteStudentBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteStudentBtn.setMaximumSize(new java.awt.Dimension(72, 52));
        deleteStudentBtn.setPreferredSize(new java.awt.Dimension(72, 52));

        studentInforBtn.setText("Student Infomation");
        studentInforBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        studentInforBtn.setMaximumSize(new java.awt.Dimension(133, 52));
        studentInforBtn.setPreferredSize(new java.awt.Dimension(133, 52));

        javax.swing.GroupLayout chucNangPanel1Layout = new javax.swing.GroupLayout(chucNangPanel1);
        chucNangPanel1.setLayout(chucNangPanel1Layout);
        chucNangPanel1Layout.setHorizontalGroup(
            chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sortLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(chucNangPanel1Layout.createSequentialGroup()
                        .addComponent(sortStudentIDBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sortStudentNameBtn)
                        .addGap(18, 18, 18)
                        .addComponent(ASC)
                        .addGap(18, 18, 18)
                        .addComponent(DESC))
                    .addGroup(chucNangPanel1Layout.createSequentialGroup()
                        .addComponent(searchStudentIDBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchStudentNameBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchStudentGradeBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isPaidDangPhiBtn)))
                .addGap(138, 138, 138)
                .addComponent(addStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(deleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(studentInforBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(showAllStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        chucNangPanel1Layout.setVerticalGroup(
            chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanel1Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(chucNangPanel1Layout.createSequentialGroup()
                        .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deleteStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(studentInforBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(showAllStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6))
                    .addGroup(chucNangPanel1Layout.createSequentialGroup()
                        .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchLabel1)
                            .addComponent(searchStudentIDBtn)
                            .addComponent(searchStudentNameBtn)
                            .addComponent(searchStudentGradeBtn)
                            .addComponent(isPaidDangPhiBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(chucNangPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sortLabel1)
                            .addComponent(sortStudentIDBtn)
                            .addComponent(sortStudentNameBtn)
                            .addComponent(ASC)
                            .addComponent(DESC)))
                    .addComponent(addStudentBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chucNangPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(chucNangPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homePanelMouseClicked
        // TODO add your handling code here:
        homeView = new HomeView();

        homeView.setLocationRelativeTo(this);

        homeView.setVisible(true);
        this.setVisible(false);

        homePanel.setBackground(new Color(255, 255, 255));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_homePanelMouseClicked

    private void doanvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doanvienPanelMouseClicked
        // TODO add your handling code here:
        doanvienView = new DoanVienView();

        doanvienView.showDoanVienView();
        doanvienView.setLocationRelativeTo(loginView);
        
        this.setVisible(false);
        doanvienView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_doanvienPanelMouseClicked

    private void dangvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dangvienPanelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dangvienPanelMouseClicked

    private void thongkePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongkePanelMouseClicked
        // TODO add your handling code here:
        thongkeView = new ThongkeView();
        
        thongkeView.setLocationRelativeTo(loginView);
        
        this.setVisible(false);
        thongkeView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        thongkeView.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_thongkePanelMouseClicked

    private void logoutPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanelMouseClicked
        // TODO add your handling code here:
        LoginView view = new LoginView();
        LoginController controller = new LoginController(view);
        // hiển thị màn hình login
        controller.showLoginView();

        this.setVisible(false);

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_logoutPanelMouseClicked

    private void sinhvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sinhvienPanelMouseClicked
        // TODO add your handling code here:
        filterView = new FilterView();
        studentView = new StudentView();

        StudentController studentController = new StudentController(studentView, filterView);
        studentController.showStudentView();
        studentView.setLocationRelativeTo(loginView);

        this.setVisible(false);
        studentView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(255, 255, 255));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_sinhvienPanelMouseClicked

    private void ASCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ASCActionPerformed
        // TODO add your handling code here:
        if (ASC.isSelected()) {
            ASCSelected = true;
            DESCSelected = false;
            DESC.setSelected(false);
        } else {
            ASCSelected = false;
        }
    }//GEN-LAST:event_ASCActionPerformed

    private void DESCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DESCActionPerformed
        // TODO add your handling code here:
        if (DESC.isSelected()) {
            DESCSelected = true;
            ASCSelected = false;
            ASC.setSelected(false);
        } else {
            DESCSelected = false;
        }
    }//GEN-LAST:event_DESCActionPerformed

    private void addStudentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addStudentBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addStudentBtnActionPerformed

    private void isPaidDangPhiBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isPaidDangPhiBtnActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_isPaidDangPhiBtnActionPerformed

    private void searchStudentIDBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchStudentIDBtnMouseClicked
        // TODO add your handling code here:
        String input = JOptionPane.showInputDialog(null, "Nhập vào ID đảng viên", "ID Input", 1);
        if (input == null || input.equals("")){
            return;
        }
        int id = Integer.parseInt(input);
        searchResultList.clear(); // Xóa kết quả trước đó
        DangVien dangvien = searchDangVienByID(id);
        if (dangvien != null) {
            searchResultList.add(dangvien);
            this.showListDangVien(searchResultList);
        }
    }//GEN-LAST:event_searchStudentIDBtnMouseClicked

    private void searchStudentNameBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchStudentNameBtnMouseClicked
        // TODO add your handling code here:
        String input = JOptionPane.showInputDialog(null, "Nhập vào Họ tên đảng viên", "Name Input", JOptionPane.QUESTION_MESSAGE);
        if (input == null || input.trim().isEmpty()) {
            return;
        }
        searchResultList = searchDangVienByName(input);
        if (searchResultList != null) {
            this.showListDangVien(searchResultList);
        }
    }//GEN-LAST:event_searchStudentNameBtnMouseClicked

    private void searchStudentGradeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchStudentGradeBtnMouseClicked
        // TODO add your handling code here:
        String input = JOptionPane.showInputDialog(null, "Nhập vào Lớp học của đảng viên", "Grade Input", JOptionPane.QUESTION_MESSAGE);
        if (input == null || input.trim().isEmpty()) {
            return; // Dừng nếu người dùng không nhập gì
        }

        searchResultList = searchDangVienByGrade(input);
        if (searchResultList != null) {
            this.showListDangVien(searchResultList);
        }
    }//GEN-LAST:event_searchStudentGradeBtnMouseClicked

    private void isPaidDangPhiBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_isPaidDangPhiBtnMouseClicked
        // TODO add your handling code here:
        searchResultList = searchDangVienPaidDoanPhi();
        if (searchResultList != null) {
                this.showListDangVien(searchResultList);
        }  
    }//GEN-LAST:event_isPaidDangPhiBtnMouseClicked

    private void sortStudentIDBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sortStudentIDBtnMouseClicked
        // TODO add your handling code here:
        List<DangVien> listToSort = searchResultList.isEmpty() ? getListDangVien() : searchResultList;

        if (this.enableDESCBtn()) {
            Collections.sort(listToSort, (d1, d2) -> Integer.compare(d2.getId(), d1.getId()));
        } else if (this.enableASCBtn()) {
            Collections.sort(listToSort, (d1, d2) -> Integer.compare(d1.getId(), d2.getId()));
        }

        this.showListDangVien(listToSort);
    }//GEN-LAST:event_sortStudentIDBtnMouseClicked

    private void sortStudentNameBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sortStudentNameBtnMouseClicked
        // TODO add your handling code here:
        List<DangVien> listToSort = searchResultList.isEmpty() ? getListDangVien() : searchResultList;
            
            if (this.enableDESCBtn()) {
                Collections.sort(listToSort, (d1, d2) -> {
                    String firstnameStu1 = d1.getName().split(" ")[d1.getName().split(" ").length - 1];
                    String firstnameStu2 = d2.getName().split(" ")[d2.getName().split(" ").length - 1];
                    return firstnameStu2.compareTo(firstnameStu1);
                });
            } else if (this.enableASCBtn()) {
                Collections.sort(listToSort, (d1, d2) -> {
                    String firstnameStu1 = d1.getName().split(" ")[d1.getName().split(" ").length - 1];
                    String firstnameStu2 = d2.getName().split(" ")[d2.getName().split(" ").length - 1];
                    return firstnameStu1.compareTo(firstnameStu2);
                });
            }
            
            this.showListDangVien(listToSort);
    }//GEN-LAST:event_sortStudentNameBtnMouseClicked

    private void showAllStudentBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showAllStudentBtnMouseClicked
        // TODO add your handling code here:
        sortDangVienByID();
        this.showListDangVien(getListDangVien());
    }//GEN-LAST:event_showAllStudentBtnMouseClicked

    private void searchStudentNameBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchStudentNameBtnMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_searchStudentNameBtnMouseEntered

    public DangVien searchDangVienByID(int id){
        List<DangVien> dangvienList = this.getListDangVien();
        try {
            for (DangVien dangvien : dangvienList){
                if (id == dangvien.getId()){
                    return dangvien;
                }
            }
            throw new IllegalArgumentException("Khong tim thay id");
        } catch (IllegalArgumentException e){
            this.showMessage("Không tìm thấy đảng viên có ID: " + id);
        }
        return null;
    }
    
    
    public List<DangVien> searchDangVienByName(String name) {
        List<DangVien> dangvienList = this.getListDangVien();
        List<DangVien> dangvienNameList = new ArrayList<>();
        try {
            for (DangVien dangvien : dangvienList) {
                if (dangvien.getName().toLowerCase().contains(name.toLowerCase())) {
                    dangvienNameList.add(dangvien);
                }
            }
            if (!dangvienNameList.isEmpty()) {
                return dangvienNameList;
            } else {
                throw new IllegalArgumentException("Không tìm thấy đảng viên có tên chứa: " + name);
            }
        } catch (IllegalArgumentException e) {
            this.showMessage("Không tìm thấy đảng viên có tên chứa: " + name);
        }
        return null;
    }

    public List<DangVien> searchDangVienByGrade(String grade) {
        List<DangVien> dangvienList = this.getListDangVien();
        List<DangVien> dangvienGradeList = new ArrayList<>();
        try {
            for (DangVien dangvien : dangvienList) {
                if (dangvien.getGrade().toLowerCase().contains(grade.toLowerCase())) {
                    dangvienGradeList.add(dangvien);
                }
            }
            if (!dangvienGradeList.isEmpty()) {
                return dangvienGradeList;
            } else {
                throw new IllegalArgumentException("Không tìm thấy đảng viên có lớp chứa: " + grade);
            }
        } catch (IllegalArgumentException e) {
            this.showMessage("Không tìm thấy đảng viên học lớp chứa: " + grade);
        }
        return null;
    }
    
    public List<DangVien> searchDangVienPaidDoanPhi(){
        List<DangVien> dangvienList = this.getListDangVien();
        List<DangVien> paidDoanPhiList = new ArrayList<>();
        try {
            int count = 0;
            for (DangVien dangvien : dangvienList){
                if (dangvien.getDangPhi() != "Chưa đóng"){
                    paidDoanPhiList.add(dangvien);
                    count++;
                }
            }
            if (count > 0) return paidDoanPhiList;
            else throw new IllegalArgumentException("Khong tim thay dangvien da dong Doan phi.");
        } catch (IllegalArgumentException e){
            this.showMessage("Chưa có đảng viên nào đã đóng Đoàn phí.");
        }
        return null;         
    }

    /**
     * sắp xếp danh sách đảng viên theo ID theo tứ tự tăng dần
     */
    public void sortDangVienByID() {
        Collections.sort(this.getListDangVien(), new Comparator<DangVien>() {
            @Override
            public int compare(DangVien d1, DangVien d2) {
                if (d1.getId() > d2.getId()) {
                    return 1;
                }
                return -1;
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ASC;
    private javax.swing.JRadioButton DESC;
    private javax.swing.JButton addStudentBtn;
    private javax.swing.JPanel chucNangPanel1;
    private javax.swing.JLabel dangvienLabel;
    private javax.swing.JPanel dangvienPanel;
    private javax.swing.JTable dangvienTable;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JButton deleteStudentBtn;
    private javax.swing.JLabel doanvienLabel;
    private javax.swing.JPanel doanvienPanel;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JButton isPaidDangPhiBtn;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel logoutPanel;
    private javax.swing.JLabel searchLabel1;
    private javax.swing.JButton searchStudentGradeBtn;
    private javax.swing.JButton searchStudentIDBtn;
    private javax.swing.JButton searchStudentNameBtn;
    private javax.swing.JButton showAllStudentBtn;
    private javax.swing.JLabel sinhvienLabel;
    private javax.swing.JPanel sinhvienPanel;
    private javax.swing.JLabel sortLabel1;
    private javax.swing.JButton sortStudentIDBtn;
    private javax.swing.JButton sortStudentNameBtn;
    private javax.swing.JButton studentInforBtn;
    private javax.swing.JLabel thongkeLabel;
    private javax.swing.JPanel thongkePanel;
    // End of variables declaration//GEN-END:variables

    public List<Integer> getListDangVienIDTable(){
        List<Integer> listDangVienID = new ArrayList<>();
        TableModel tableModel = dangvienTable.getModel();
        int rowCount = tableModel.getRowCount();
        
        for (int i=0; i< rowCount; i++){
            int id = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
            listDangVienID.add(id);
        }
        return listDangVienID;
    }

    public JTable getDangVienTable(){
        return this.dangvienTable;
    }
    
    public int getStuTabSelectedRow(){
        return dangvienTable.getSelectedRow();
    }
    
    public boolean enableASCBtn(){
        return ASCSelected;
    }
    public boolean enableDESCBtn(){
        return DESCSelected;
    }
    
    public void addSortDangVienIDListener(ActionListener listener) {
        sortStudentIDBtn.addActionListener(listener);
    }
    
    public void addSortDangVienNameListener(ActionListener listener) {
        sortStudentNameBtn.addActionListener(listener);
    }
    
    public void addShowAllDangVienListener(ActionListener listener){
        showAllStudentBtn.addActionListener(listener);
    }
    
    public void addSearchDangVienIDListener(ActionListener listener){
        searchStudentIDBtn.addActionListener(listener);
    }
    
    public void addSearchDangVienNameListener(ActionListener listener){
        searchStudentNameBtn.addActionListener(listener);
    }
    
    public void addSearchDangVienGradeListener(ActionListener listener){
        searchStudentGradeBtn.addActionListener(listener);
    }
    
    public void addSearchDangVienPaidDangPhi(ActionListener listener){
        isPaidDangPhiBtn.addActionListener(listener);
    }
    
    public void addListDangVienSelectionListener(ListSelectionListener listener) {
        dangvienTable.getSelectionModel().addListSelectionListener(listener);
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}
