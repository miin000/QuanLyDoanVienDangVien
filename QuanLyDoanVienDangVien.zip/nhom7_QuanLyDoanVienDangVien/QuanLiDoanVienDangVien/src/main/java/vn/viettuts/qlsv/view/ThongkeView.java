
package vn.viettuts.qlsv.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import vn.viettuts.qlsv.controller.LoginController;
import vn.viettuts.qlsv.controller.StudentController;
import vn.viettuts.qlsv.dao.StudentDao;
import vn.viettuts.qlsv.entity.DoanVien;
import vn.viettuts.qlsv.entity.Student;
/**
 *
 * @author miin
 */
public class ThongkeView extends javax.swing.JFrame {
    private LoginView loginView = new LoginView();
    private StudentView studentView;
    private HomeView homeView;
    private DoanVienView doanvienView;
    private DangVienView dangvienView;
    private FilterView filterView;
    private StudentDao studentDao;
    
    private int index;
    DefaultTableModel model1;
    DefaultTableModel model2;
    
    private String [] ColumnDoanVien = new String [] {
        "ID", "Họ và tên", "Tuổi", "Lớp", "Địa chỉ", "Ngày vào Đoàn", "Nơi vào Đoàn", "Trạng thái"};
    private String [] ColumnDongPhi = new String [] {
        "ID", "Họ và tên", "Tuổi", "Lớp", "Địa chỉ", "Đoàn phí", "Đảng Phí"};
    private Object data1 = new Object [][] {};
    private Object data2 = new Object [][] {};
    /**
     * Creates new form ThongkeView
     */
    public ThongkeView() {
        initComponents();
        customizeComponents();
        loadImage();
        
        setQuantity();
        
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }
    
    private void customizeComponents() {    
        model1 = (DefaultTableModel) dvttTable.getModel();
        model2 = (DefaultTableModel) dongphiTable.getModel();
        
        // cài đặt các cột và data cho bảng student
        dvttTable.setModel(new DefaultTableModel((Object[][]) data1, ColumnDoanVien));
        dongphiTable.setModel(new DefaultTableModel((Object[][]) data2, ColumnDongPhi));
    }
    
    public void setQuantity() {
        doanvienView = new DoanVienView();
        dangvienView = new DangVienView();
        
        String slSV = doanvienView.getQuantityDoanVien();
        String slDV = dangvienView.getQuantityDangVien();
        
        slSVLabel.setText(slSV);
        slDoanVienLabel.setText(slSV);
        slDangVienLabel.setText(slDV);
    }
    
    private void loadImage() {
        try {
            // Tải ảnh từ resources bằng getResourceAsStream
            InputStream logoStream = getClass().getResourceAsStream("/images/logo.jpg");
            InputStream svStream = getClass().getResourceAsStream("/images/sinhvien.jpg");
            InputStream doanvienStream = getClass().getResourceAsStream("/images/doanvien.jpg");
            InputStream dangvienStream = getClass().getResourceAsStream("/images/dangvien.jpg");
            
            // Đọc ảnh từ InputStream
            BufferedImage originalImage1 = ImageIO.read(logoStream);
            BufferedImage svImgO = ImageIO.read(svStream);
            BufferedImage doanvienImgO = ImageIO.read(doanvienStream);
            BufferedImage dangvienImgO = ImageIO.read(dangvienStream);

            // Đóng các stream sau khi đọc
            if (logoStream != null) logoStream.close();
            if (svStream != null) svStream.close();
            if (doanvienStream != null) doanvienStream.close();
            if (dangvienStream != null) dangvienStream.close();

            // Kích thước mong muốn cho JLabel
            int labelWidth1 = logoLabel.getWidth();
            int labelHeight1 = logoLabel.getHeight();
            
            int labelWidth2 = imgSVLabel.getWidth();
            int labelHeight2 = imgSVLabel.getHeight();

            // Điều chỉnh kích thước ảnh
            Image scaledImage1 = originalImage1.getScaledInstance(labelWidth1, labelHeight1, Image.SCALE_SMOOTH);
            Image svImg = svImgO.getScaledInstance(labelWidth2, labelHeight2, Image.SCALE_SMOOTH);
            Image doanvienImg = doanvienImgO.getScaledInstance(labelWidth2, labelHeight2, Image.SCALE_SMOOTH);
            Image dangvienImg = dangvienImgO.getScaledInstance(labelWidth2, labelHeight2, Image.SCALE_SMOOTH);

            // Đặt ảnh đã chỉnh kích thước vào JLabel
            logoLabel.setIcon(new ImageIcon(scaledImage1));
            imgSVLabel.setIcon(new ImageIcon(svImg));
            imgDoanVienLabel.setIcon(new ImageIcon(doanvienImg));
            imgDangVienLabel.setIcon(new ImageIcon(dangvienImg));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
        public void showListDoanVienTK(List<DoanVien> list) {
            model1.setRowCount(0); // Xóa dữ liệu cũ

            // Lọc danh sách đoàn viên chỉ chứa những người trên 30 tuổi
            List<DoanVien> filteredList = list.stream()
                                              .filter(dv -> dv.getAge() >= 30)
                                              .collect(Collectors.toList());

            int size = filteredList.size();
            Object[][] listDoanVien = new Object[size][8];

            for (int i = 0; i < size; i++) {
                listDoanVien[i][0] = filteredList.get(i).getId();
                listDoanVien[i][1] = filteredList.get(i).getName();
                listDoanVien[i][2] = filteredList.get(i).getAge();
                listDoanVien[i][3] = filteredList.get(i).getGrade();
                listDoanVien[i][4] = filteredList.get(i).getAddress();
                listDoanVien[i][5] = filteredList.get(i).getDateJoinDoan();
                listDoanVien[i][6] = filteredList.get(i).getPlaceJoinDoan();
                listDoanVien[i][7] = filteredList.get(i).getStatus();
            }

            // Cập nhật bảng với danh sách lọc
            dvttTable.setModel(new DefaultTableModel(listDoanVien, ColumnDoanVien));

            // Đặt lại kích thước cột
            TableColumnModel colStudentModel = dvttTable.getColumnModel();
            colStudentModel.getColumn(0).setPreferredWidth(32);
            colStudentModel.getColumn(1).setPreferredWidth(140);
            colStudentModel.getColumn(2).setPreferredWidth(38);
            colStudentModel.getColumn(3).setPreferredWidth(45);
            colStudentModel.getColumn(4).setPreferredWidth(80);
            colStudentModel.getColumn(5).setPreferredWidth(100);
            colStudentModel.getColumn(6).setPreferredWidth(140);
            colStudentModel.getColumn(7).setPreferredWidth(100);
        }

        public void showListDongPhi(List<Student> list) {
            int size = list.size();
            // với bảng studentTable có 15 cột, 
            // khởi tạo mảng 2 chiều students, trong đó:
            // số hàng: là kích thước của list student 
            // số cột: là 15
            Object [][] students = new Object[size][7];
            for (int i = 0; i < size; i++) {
                students[i][0] = list.get(i).getId();
                students[i][1] = list.get(i).getName();
                students[i][2] = list.get(i).getAge();
                students[i][3] = list.get(i).getGrade();
                students[i][4] = list.get(i).getAddress();

                if (list.get(i).isDoanPhi()) students[i][5] = "Đã đóng";
                else students[i][5] = "Chưa đóng";
                if (list.get(i).isDangPhi()) students[i][6] = "Đã đóng";
                else students[i][6] = "Chưa đóng";
            }
            // Edit table
            dongphiTable.setModel(new DefaultTableModel(students, ColumnDongPhi));
            TableColumnModel colStudentModel = dongphiTable.getColumnModel();
            colStudentModel.getColumn(0).setPreferredWidth(32);   
            colStudentModel.getColumn(1).setPreferredWidth(125);   
            colStudentModel.getColumn(2).setPreferredWidth(38);
            colStudentModel.getColumn(3).setPreferredWidth(45);
            colStudentModel.getColumn(4).setPreferredWidth(55);
            colStudentModel.getColumn(5).setPreferredWidth(40);
            colStudentModel.getColumn(6).setPreferredWidth(108);   

        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        countPanel = new javax.swing.JPanel();
        countSVPanel = new javax.swing.JPanel();
        imgSVLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        slSVLabel = new javax.swing.JLabel();
        countDoanVienPanel = new javax.swing.JPanel();
        imgDoanVienLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        slDoanVienLabel = new javax.swing.JLabel();
        countDangVienPanel = new javax.swing.JPanel();
        imgDangVienLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        slDangVienLabel = new javax.swing.JLabel();
        viewPanel = new javax.swing.JPanel();
        tabbedPane = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        phongtraoInfoPanel = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        slptLabel = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        slsvptLabel = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        phongtraoTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        khenthuongInfoPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        slsvktLabel = new javax.swing.JLabel();
        slktLabel = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        khenthuongTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        kyluatInfoPanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        slklLabel = new javax.swing.JLabel();
        slsvklLabel = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        kyluatTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        dvttInfoPanel = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        dtttLabel = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        dvttTable = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        dongphiInfoPanel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        doandaLabel = new javax.swing.JLabel();
        dangdaLabel = new javax.swing.JLabel();
        doanchuaLabel = new javax.swing.JLabel();
        dangchuaLabel = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        dongphiTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        doanvienPanel = new javax.swing.JPanel();
        doanvienLabel = new javax.swing.JLabel();
        dangvienPanel = new javax.swing.JPanel();
        dangvienLabel = new javax.swing.JLabel();
        thongkePanel = new javax.swing.JPanel();
        thongkeLabel = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        logoutPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        sinhvienPanel = new javax.swing.JPanel();
        sinhvienLabel = new javax.swing.JLabel();
        logoPanel = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Thống kê");

        countSVPanel.setBackground(new java.awt.Color(0, 204, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Số lượng sinh viên");

        slSVLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        slSVLabel.setForeground(new java.awt.Color(255, 255, 255));
        slSVLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout countSVPanelLayout = new javax.swing.GroupLayout(countSVPanel);
        countSVPanel.setLayout(countSVPanelLayout);
        countSVPanelLayout.setHorizontalGroup(
            countSVPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(countSVPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgSVLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(countSVPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(slSVLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        countSVPanelLayout.setVerticalGroup(
            countSVPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, countSVPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(countSVPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(countSVPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(slSVLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(imgSVLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        countDoanVienPanel.setBackground(new java.awt.Color(255, 51, 0));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Số lượng đoàn viên");

        slDoanVienLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        slDoanVienLabel.setForeground(new java.awt.Color(255, 255, 255));
        slDoanVienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout countDoanVienPanelLayout = new javax.swing.GroupLayout(countDoanVienPanel);
        countDoanVienPanel.setLayout(countDoanVienPanelLayout);
        countDoanVienPanelLayout.setHorizontalGroup(
            countDoanVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(countDoanVienPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgDoanVienLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(countDoanVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(slDoanVienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        countDoanVienPanelLayout.setVerticalGroup(
            countDoanVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, countDoanVienPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(countDoanVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(countDoanVienPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(slDoanVienLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(imgDoanVienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        countDangVienPanel.setBackground(new java.awt.Color(255, 204, 0));
        countDangVienPanel.setPreferredSize(new java.awt.Dimension(448, 12));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Số lượng đảng viên");

        slDangVienLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        slDangVienLabel.setForeground(new java.awt.Color(255, 255, 255));
        slDangVienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout countDangVienPanelLayout = new javax.swing.GroupLayout(countDangVienPanel);
        countDangVienPanel.setLayout(countDangVienPanelLayout);
        countDangVienPanelLayout.setHorizontalGroup(
            countDangVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(countDangVienPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgDangVienLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(countDangVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(slDangVienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        countDangVienPanelLayout.setVerticalGroup(
            countDangVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, countDangVienPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(countDangVienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(countDangVienPanelLayout.createSequentialGroup()
                        .addGap(0, 13, Short.MAX_VALUE)
                        .addComponent(slDangVienLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(imgDangVienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout countPanelLayout = new javax.swing.GroupLayout(countPanel);
        countPanel.setLayout(countPanelLayout);
        countPanelLayout.setHorizontalGroup(
            countPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(countPanelLayout.createSequentialGroup()
                .addComponent(countSVPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(countDoanVienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(countDangVienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        countPanelLayout.setVerticalGroup(
            countPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(countSVPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(countDoanVienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(countDangVienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        tabbedPane.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tabbedPaneStateChanged(evt);
            }
        });
        tabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabbedPaneMouseClicked(evt);
            }
        });

        phongtraoInfoPanel.setBackground(new java.awt.Color(255, 255, 204));
        phongtraoInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Tổng quan"));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Số lượng phong trào: ");

        slptLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slptLabel.setForeground(new java.awt.Color(255, 51, 51));
        slptLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Số lượng sinh viên tham gia các phong trào: ");

        slsvptLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slsvptLabel.setForeground(new java.awt.Color(255, 51, 51));
        slsvptLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout phongtraoInfoPanelLayout = new javax.swing.GroupLayout(phongtraoInfoPanel);
        phongtraoInfoPanel.setLayout(phongtraoInfoPanelLayout);
        phongtraoInfoPanelLayout.setHorizontalGroup(
            phongtraoInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(phongtraoInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(phongtraoInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(phongtraoInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slsvptLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(phongtraoInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slptLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        phongtraoInfoPanelLayout.setVerticalGroup(
            phongtraoInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(phongtraoInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(phongtraoInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slptLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(phongtraoInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slsvptLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(171, Short.MAX_VALUE))
        );

        phongtraoTable.setBackground(new java.awt.Color(255, 255, 204));
        phongtraoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(phongtraoTable);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(phongtraoInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(phongtraoInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Phong trào", jPanel2);

        khenthuongInfoPanel.setBackground(new java.awt.Color(255, 255, 204));
        khenthuongInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Tổng quan"));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Số lượng loại khen thưởng: ");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setText("Số lượng sinh viên được khen thưởng: ");

        slsvktLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slsvktLabel.setForeground(new java.awt.Color(255, 51, 51));
        slsvktLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        slktLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slktLabel.setForeground(new java.awt.Color(255, 51, 51));
        slktLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout khenthuongInfoPanelLayout = new javax.swing.GroupLayout(khenthuongInfoPanel);
        khenthuongInfoPanel.setLayout(khenthuongInfoPanelLayout);
        khenthuongInfoPanelLayout.setHorizontalGroup(
            khenthuongInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(khenthuongInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(khenthuongInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(khenthuongInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slktLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(khenthuongInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slsvktLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(89, Short.MAX_VALUE))
        );
        khenthuongInfoPanelLayout.setVerticalGroup(
            khenthuongInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(khenthuongInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(khenthuongInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slktLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(khenthuongInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slsvktLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(171, Short.MAX_VALUE))
        );

        khenthuongTable.setBackground(new java.awt.Color(255, 255, 204));
        khenthuongTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(khenthuongTable);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(khenthuongInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(khenthuongInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabbedPane.addTab("Khen thưởng", jPanel4);

        kyluatInfoPanel.setBackground(new java.awt.Color(255, 255, 204));
        kyluatInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Tổng quan"));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Số lượng loại kỷ luật: ");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setText("Số lượng sinh viên bị kỷ luật: ");

        slklLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slklLabel.setForeground(new java.awt.Color(255, 51, 51));
        slklLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        slsvklLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        slsvklLabel.setForeground(new java.awt.Color(255, 51, 51));
        slsvklLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout kyluatInfoPanelLayout = new javax.swing.GroupLayout(kyluatInfoPanel);
        kyluatInfoPanel.setLayout(kyluatInfoPanelLayout);
        kyluatInfoPanelLayout.setHorizontalGroup(
            kyluatInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kyluatInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kyluatInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kyluatInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slklLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(kyluatInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slsvklLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        kyluatInfoPanelLayout.setVerticalGroup(
            kyluatInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kyluatInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kyluatInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slklLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(kyluatInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slsvklLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(171, Short.MAX_VALUE))
        );

        kyluatTable.setBackground(new java.awt.Color(255, 255, 204));
        kyluatTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(kyluatTable);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(kyluatInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(kyluatInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabbedPane.addTab("Kỷ luật", jPanel5);

        dvttInfoPanel.setBackground(new java.awt.Color(255, 255, 204));
        dvttInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Tổng quan"));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setText("Số lượng đoàn viên trưởng thành: ");

        dtttLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dtttLabel.setForeground(new java.awt.Color(255, 51, 51));
        dtttLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout dvttInfoPanelLayout = new javax.swing.GroupLayout(dvttInfoPanel);
        dvttInfoPanel.setLayout(dvttInfoPanelLayout);
        dvttInfoPanelLayout.setHorizontalGroup(
            dvttInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dvttInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dtttLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );
        dvttInfoPanelLayout.setVerticalGroup(
            dvttInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dvttInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dvttInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dtttLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(239, Short.MAX_VALUE))
        );

        dvttTable.setBackground(new java.awt.Color(255, 255, 204));
        dvttTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(dvttTable);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(dvttInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dvttInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabbedPane.addTab("Đoàn viên trưởng thành", jPanel6);

        dongphiInfoPanel.setBackground(new java.awt.Color(255, 255, 204));
        dongphiInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Tổng quan"));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel13.setText("Số lượng đã đóng phí Đoàn: ");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel14.setText("Số lượng đã đóng phí Đảng: ");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel15.setText("Số lượng chưa đóng phí Đoàn: ");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel16.setText("Số lượng chưa đóng phí Đảng: ");

        doandaLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        doandaLabel.setForeground(new java.awt.Color(255, 51, 51));
        doandaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        dangdaLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dangdaLabel.setForeground(new java.awt.Color(255, 51, 51));
        dangdaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        doanchuaLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        doanchuaLabel.setForeground(new java.awt.Color(255, 51, 51));
        doanchuaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        dangchuaLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dangchuaLabel.setForeground(new java.awt.Color(255, 51, 51));
        dangchuaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout dongphiInfoPanelLayout = new javax.swing.GroupLayout(dongphiInfoPanel);
        dongphiInfoPanel.setLayout(dongphiInfoPanelLayout);
        dongphiInfoPanelLayout.setHorizontalGroup(
            dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dongphiInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dongphiInfoPanelLayout.createSequentialGroup()
                        .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(doanchuaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dangchuaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(dongphiInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(doandaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(dongphiInfoPanelLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dangdaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(147, Short.MAX_VALUE))
        );
        dongphiInfoPanelLayout.setVerticalGroup(
            dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dongphiInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doandaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dangdaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doanchuaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dongphiInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dangchuaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dongphiTable.setBackground(new java.awt.Color(255, 255, 204));
        dongphiTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(dongphiTable);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(dongphiInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dongphiInfoPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabbedPane.addTab("Đóng phí", jPanel7);

        javax.swing.GroupLayout viewPanelLayout = new javax.swing.GroupLayout(viewPanel);
        viewPanel.setLayout(viewPanelLayout);
        viewPanelLayout.setHorizontalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );
        viewPanelLayout.setVerticalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        tabbedPane.getAccessibleContext().setAccessibleName("Phong trào");

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(viewPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(countPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(countPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 204, 204));

        homePanel.setBackground(new java.awt.Color(0, 204, 204));
        homePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homePanelMouseClicked(evt);
            }
        });

        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        homeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        homeLabel.setText("Home");
        homeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        doanvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        doanvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doanvienPanelMouseClicked(evt);
            }
        });

        doanvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        doanvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        doanvienLabel.setText("Đoàn viên");
        doanvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout doanvienPanelLayout = new javax.swing.GroupLayout(doanvienPanel);
        doanvienPanel.setLayout(doanvienPanelLayout);
        doanvienPanelLayout.setHorizontalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        doanvienPanelLayout.setVerticalGroup(
            doanvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dangvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        dangvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dangvienPanelMouseClicked(evt);
            }
        });

        dangvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dangvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dangvienLabel.setText("Đảng viên");
        dangvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout dangvienPanelLayout = new javax.swing.GroupLayout(dangvienPanel);
        dangvienPanel.setLayout(dangvienPanelLayout);
        dangvienPanelLayout.setHorizontalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        dangvienPanelLayout.setVerticalGroup(
            dangvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongkePanel.setBackground(new java.awt.Color(0, 204, 204));
        thongkePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongkePanelMouseClicked(evt);
            }
        });

        thongkeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        thongkeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        thongkeLabel.setText("Thống kê");
        thongkeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout thongkePanelLayout = new javax.swing.GroupLayout(thongkePanel);
        thongkePanel.setLayout(thongkePanelLayout);
        thongkePanelLayout.setHorizontalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongkePanelLayout.setVerticalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(thongkeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashboardLabel.setText("DASHBOARD");

        logoutPanel.setBackground(new java.awt.Color(0, 204, 204));
        logoutPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanelMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Đăng xuất\n");

        javax.swing.GroupLayout logoutPanelLayout = new javax.swing.GroupLayout(logoutPanel);
        logoutPanel.setLayout(logoutPanelLayout);
        logoutPanelLayout.setHorizontalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoutPanelLayout.setVerticalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        sinhvienPanel.setBackground(new java.awt.Color(0, 204, 204));
        sinhvienPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sinhvienPanelMouseClicked(evt);
            }
        });

        sinhvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        sinhvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sinhvienLabel.setText("Sinh viên");
        sinhvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout sinhvienPanelLayout = new javax.swing.GroupLayout(sinhvienPanel);
        sinhvienPanel.setLayout(sinhvienPanelLayout);
        sinhvienPanelLayout.setHorizontalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        sinhvienPanelLayout.setVerticalGroup(
            sinhvienPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(doanvienPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dangvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongkePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logoutPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(sinhvienPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(homePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sinhvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(doanvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dangvienPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongkePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(logoutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout logoPanelLayout = new javax.swing.GroupLayout(logoPanel);
        logoPanel.setLayout(logoPanelLayout);
        logoPanelLayout.setHorizontalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
        );
        logoPanelLayout.setVerticalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Hệ thống thống kê");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homePanelMouseClicked
        // TODO add your handling code here:
        homeView = new HomeView();

        homeView.setLocationRelativeTo(this);

        homeView.setVisible(true);
        this.setVisible(false);

        homePanel.setBackground(new Color(255, 255, 255));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_homePanelMouseClicked

    private void doanvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doanvienPanelMouseClicked
        // TODO add your handling code here:
        doanvienView = new DoanVienView();

        doanvienView.setLocationRelativeTo(loginView);
        doanvienView.showDoanVienView();
        this.setVisible(false);
        doanvienView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(255, 255, 255));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_doanvienPanelMouseClicked

    private void dangvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dangvienPanelMouseClicked
        // TODO add your handling code here:
        dangvienView = new DangVienView();
        
        dangvienView.showDangVienView();
        dangvienView.setLocationRelativeTo(loginView);
        
        this.setVisible(false);
        dangvienView.setVisible(true);
         
        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(255, 255, 255));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_dangvienPanelMouseClicked

    private void thongkePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongkePanelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_thongkePanelMouseClicked

    private void logoutPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanelMouseClicked
        // TODO add your handling code here:
        LoginView view = new LoginView();
        LoginController controller = new LoginController(view);
        // hiển thị màn hình login
        controller.showLoginView();

        this.setVisible(false);

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(0, 204, 204));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_logoutPanelMouseClicked

    private void sinhvienPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sinhvienPanelMouseClicked
        // TODO add your handling code here:
        filterView = new FilterView();
        studentView = new StudentView();

        StudentController studentController = new StudentController(studentView, filterView);
        studentController.showStudentView();
        studentView.setLocationRelativeTo(loginView);

        this.setVisible(false);
        studentView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        sinhvienPanel.setBackground(new Color(255, 255, 255));
        doanvienPanel.setBackground(new Color(0, 204, 204));
        dangvienPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
        logoutPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_sinhvienPanelMouseClicked

    private void tabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabbedPaneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tabbedPaneMouseClicked

    private void tabbedPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tabbedPaneStateChanged
        // TODO add your handling code here:
        index = tabbedPane.getSelectedIndex();
        studentDao = new StudentDao();
        List<Student> studentList = studentDao.getListStudents();
        setQuantity(studentList);

        if (index == 0) {
            Map<String, Integer> activityMap = countParticipation(studentList, "activity");
            showParticipationTable(activityMap, "Phong trào");
        } else if (index == 1){
            Map<String, Integer> rewardMap = countParticipation(studentList, "reward");
            showParticipationTable(rewardMap, "Khen thưởng");
        }else if (index == 2) {
            Map<String, Integer> punishmentMap = countParticipation(studentList, "punishment");
            showParticipationTable(punishmentMap, "Kỷ luật");
        } else if (index == 3) {
            doanvienView = new DoanVienView();
            List<DoanVien> listDv = doanvienView.getListDoanVien();
            showListDoanVienTK(listDv);
            int doanVienTTint=0;
            
            for (DoanVien dv : listDv) {
                if (dv.getAge() >= 30){
                    doanVienTTint++;
                }
            }
            
            String doanVienTT = String.valueOf(doanVienTTint);
            dtttLabel.setText(doanVienTT);
        } else if (index == 4) {
            List<Student> listDp = studentDao.getListStudents();
            showListDongPhi(listDp);
            
            int dadongphiDoan = 0;
            int dadongphiDang = 0;
            int chuadongphiDoan = 0;
            int chuadongphiDang = 0;
            
            for (Student sv : listDp) {
                if (sv.isDoanPhi()) {
                    dadongphiDoan++;
                }else {
                    chuadongphiDoan++;
                }
                if (sv.isDangPhi()) {
                    dadongphiDang++;
                }else {
                    chuadongphiDang++;
                }
            }
            
            String daPhiDoan = String.valueOf(dadongphiDoan);
            String chuaPhiDoan = String.valueOf(chuadongphiDoan);
            String daPhiDang = String.valueOf(dadongphiDang);
            String chuaPhiDang = String.valueOf(chuadongphiDang);
            
            doandaLabel.setText(daPhiDoan);
            doanchuaLabel.setText(chuaPhiDoan);
            dangdaLabel.setText(daPhiDang);
            dangchuaLabel.setText(chuaPhiDang);
        }
    }//GEN-LAST:event_tabbedPaneStateChanged

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(ThongkeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(ThongkeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(ThongkeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(ThongkeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new ThongkeView().setVisible(true);
//            }
//        });
//    }
    
    public Map<String, Integer> countParticipation(List<Student> studentList, String type) {
        Map<String, Integer> participationMap = new HashMap<>();

        for (Student student : studentList) {
            String data;
            if ("reward".equals(type)) {
                data = student.getReward();
            } else if ("punishment".equals(type)) {
                data = student.getPunishment();
            } else {
                data = student.getActivity();
            }

            if (data != null && !data.isEmpty()) {
                // Tách chuỗi thành danh sách các mục
                String[] items = data.split(",");
                for (String item : items) {
                    item = item.trim(); // Bỏ khoảng trắng
                    // Bỏ qua các giá trị "Chưa tham gia" và "Không có"
                    if (!item.equals("Chưa tham gia") && !item.equals("Không có")) {
                        participationMap.put(item, participationMap.getOrDefault(item, 0) + 1);
                    }
                }
            }
        }

        return participationMap;
    }

    
    public void showParticipationTable(Map<String, Integer> participationMap, String tableName) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("STT");
        model.addColumn("Tên " + tableName);
        model.addColumn("Số lượng sinh viên");

        int stt = 1;
        for (Map.Entry<String, Integer> entry : participationMap.entrySet()) {
            model.addRow(new Object[]{stt++, entry.getKey(), entry.getValue()});
        }

        switch (tableName) {
            case "Phong trào":
                phongtraoTable.setModel(model);
                break;
            case "Khen thưởng":
                khenthuongTable.setModel(model);
                break;
            case "Kỷ luật":
                kyluatTable.setModel(model);
                break;
            default:
                System.out.println("Tên bảng không hợp lệ: " + tableName);
                break;
        }
    }
    
    public Map<String, Integer> calculateOverview(List<Student> studentList, String attribute) {
        Set<String> uniqueTypes = new HashSet<>(); // Để đếm các loại mục hợp lệ
        int studentCount = 0;

        for (Student student : studentList) {
            String value = "";

            // Xác định thuộc tính (reward, punishment, activity) dựa trên attribute
            switch (attribute) {
                case "reward":
                    value = student.getReward();
                    break;
                case "punishment":
                    value = student.getPunishment();
                    break;
                case "activity":
                    value = student.getActivity();
                    break;
            }

            // Kiểm tra giá trị hợp lệ và bỏ qua các giá trị "Chưa tham gia" và "Không có"
            if (value == null || value.isEmpty() || value.equals("Chưa tham gia") || value.equals("Không có")) {
                continue;
            }

            // Tách chuỗi thành danh sách các mục nếu có nhiều mục
            String[] items = value.split(",");
            boolean counted = false;

            for (String item : items) {
                item = item.trim();
                if (!item.equals("Chưa tham gia") && !item.equals("Không có")) {
                    uniqueTypes.add(item);
                    counted = true;
                }
            }

            // Tăng số lượng sinh viên nếu có ít nhất một mục hợp lệ
            if (counted) {
                studentCount++;
            }
        }

        // Đưa kết quả vào Map
        Map<String, Integer> overview = new HashMap<>();
        overview.put("Số loại " + attribute, uniqueTypes.size());   // Đếm số loại mục
        overview.put("Số lượng sinh viên tham gia", studentCount);  // Đếm số sinh viên tham gia

        return overview;
    }


    public void setQuantity(List<Student> studentList) {
        // Tính tổng quan cho từng loại
        Map<String, Integer> rewardOverview = calculateOverview(studentList, "reward");
        Map<String, Integer> punishmentOverview = calculateOverview(studentList, "punishment");
        Map<String, Integer> activityOverview = calculateOverview(studentList, "activity");

        // Lấy số loại và số lượng sinh viên tham gia từ Map
        int rewardTypes = rewardOverview.get("Số loại reward");
        int rewardStudents = rewardOverview.get("Số lượng sinh viên tham gia");

        int punishmentTypes = punishmentOverview.get("Số loại punishment");
        int punishmentStudents = punishmentOverview.get("Số lượng sinh viên tham gia");

        int activityTypes = activityOverview.get("Số loại activity");
        int activityStudents = activityOverview.get("Số lượng sinh viên tham gia");

        // Cập nhật JLabel với số liệu
        slptLabel.setText(String.valueOf(activityTypes));
        slsvptLabel.setText(String.valueOf(activityStudents));
        slktLabel.setText(String.valueOf(rewardTypes));
        slsvktLabel.setText(String.valueOf(rewardStudents));
        slklLabel.setText(String.valueOf(punishmentTypes));
        slsvklLabel.setText(String.valueOf(punishmentStudents));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel countDangVienPanel;
    private javax.swing.JPanel countDoanVienPanel;
    private javax.swing.JPanel countPanel;
    private javax.swing.JPanel countSVPanel;
    private javax.swing.JLabel dangchuaLabel;
    private javax.swing.JLabel dangdaLabel;
    private javax.swing.JLabel dangvienLabel;
    private javax.swing.JPanel dangvienPanel;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JLabel doanchuaLabel;
    private javax.swing.JLabel doandaLabel;
    private javax.swing.JLabel doanvienLabel;
    private javax.swing.JPanel doanvienPanel;
    private javax.swing.JPanel dongphiInfoPanel;
    private javax.swing.JTable dongphiTable;
    private javax.swing.JLabel dtttLabel;
    private javax.swing.JPanel dvttInfoPanel;
    private javax.swing.JTable dvttTable;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JLabel imgDangVienLabel;
    private javax.swing.JLabel imgDoanVienLabel;
    private javax.swing.JLabel imgSVLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JPanel khenthuongInfoPanel;
    private javax.swing.JTable khenthuongTable;
    private javax.swing.JPanel kyluatInfoPanel;
    private javax.swing.JTable kyluatTable;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel logoutPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel phongtraoInfoPanel;
    private javax.swing.JTable phongtraoTable;
    private javax.swing.JLabel sinhvienLabel;
    private javax.swing.JPanel sinhvienPanel;
    private javax.swing.JLabel slDangVienLabel;
    private javax.swing.JLabel slDoanVienLabel;
    private javax.swing.JLabel slSVLabel;
    private javax.swing.JLabel slklLabel;
    private javax.swing.JLabel slktLabel;
    private javax.swing.JLabel slptLabel;
    private javax.swing.JLabel slsvklLabel;
    private javax.swing.JLabel slsvktLabel;
    private javax.swing.JLabel slsvptLabel;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JLabel thongkeLabel;
    private javax.swing.JPanel thongkePanel;
    private javax.swing.JPanel viewPanel;
    // End of variables declaration//GEN-END:variables
}
