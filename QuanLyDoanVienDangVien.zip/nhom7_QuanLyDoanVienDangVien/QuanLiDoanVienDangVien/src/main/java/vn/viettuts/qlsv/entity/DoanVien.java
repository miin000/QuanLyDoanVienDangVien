package vn.viettuts.qlsv.entity;

/**
 *
 * @author miin
 */
public class DoanVien {
    private static final long serialVersionUID = 1L;
    private int id;
    private String name, grade, address, reward, punishment, activity, status;
    private String placeJoinDoan;
    private String dateJoinDoan;
    private String doanPhi;
    private byte age;

    public DoanVien() {
    }

    public DoanVien(int id, String name, String grade, String address, String status, String placeJoinDoan, String dateJoinDoan, String doanPhi, byte age, String reward, String punishment, String activity) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.address = address;
        this.reward = reward;
        this.punishment = punishment;
        this.activity = activity;
        this.status = status;
        this.placeJoinDoan = placeJoinDoan;
        this.dateJoinDoan = dateJoinDoan;
        this.doanPhi = doanPhi;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getPunishment() {
        return punishment;
    }

    public void setPunishment(String punishment) {
        this.punishment = punishment;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPlaceJoinDoan() {
        return placeJoinDoan;
    }

    public void setPlaceJoinDoan(String placeJoinDoan) {
        this.placeJoinDoan = placeJoinDoan;
    }

    public String getDateJoinDoan() {
        return dateJoinDoan;
    }

    public void setDateJoinDoan(String dateJoinDoan) {
        this.dateJoinDoan = dateJoinDoan;
    }

    public String getDoanPhi() {
        return doanPhi;
    }

    public void setDoanPhi(String isDoanPhi) {
        this.doanPhi = isDoanPhi;
    }

    public byte getAge() {
        return age;
    }

    public void setAge(byte age) {
        this.age = age;
    }
    
}
